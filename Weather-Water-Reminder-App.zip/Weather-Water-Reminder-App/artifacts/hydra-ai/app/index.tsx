import React from "react";
import { ActivityIndicator, View } from "react-native";
import { Redirect } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { useHydration } from "@/context/HydrationContext";

export default function IndexRoute() {
  const { ready, profile } = useHydration();
  const colors = useColors();
  if (!ready) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }
  return <Redirect href={profile ? "/(tabs)" : "/onboarding"} />;
}
