import React, { useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  Platform,
  StyleSheet,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { AppIcon as Feather } from "@/components/AppIcon";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { ActionButton, AppText, Card, Field, InlineNotice, Pill } from "@/components/Kit";
import { useHydration } from "@/context/HydrationContext";
import { openDeviceSettings, requestDeviceLocation } from "@/lib/location";
import type { ActivityLevel, Gender, SavedLocation, UserProfile } from "@/lib/hydration";
import { useColors } from "@/hooks/useColors";
import { getSearchWeatherLocationsQueryKey, useSearchWeatherLocations } from "@workspace/api-client-react";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const genders: { key: Gender; label: string }[] = [
  { key: "woman", label: "Woman" },
  { key: "man", label: "Man" },
  { key: "nonbinary", label: "Non-binary" },
  { key: "undisclosed", label: "Prefer not to say" },
];
const activityOptions: { key: ActivityLevel; label: string }[] = [
  { key: "low", label: "Light" },
  { key: "moderate", label: "Moderate" },
  { key: "high", label: "Active" },
];

export default function OnboardingScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { finishSetup } = useHydration();
  const [name, setName] = useState("");
  const [age, setAge] = useState("25");
  const [weight, setWeight] = useState("60");
  const [gender, setGender] = useState<Gender>("undisclosed");
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>("moderate");
  const [city, setCity] = useState("");
  const [searchedCity, setSearchedCity] = useState("");
  const [location, setLocation] = useState<SavedLocation | null>(null);
  const [error, setError] = useState("");
  const [locationSettingsRequired, setLocationSettingsRequired] = useState(false);
  const [working, setWorking] = useState(false);
  const placeQuery = useSearchWeatherLocations(
    { city: searchedCity },
    {
      query: {
        queryKey: getSearchWeatherLocationsQueryKey({ city: searchedCity }),
        enabled: searchedCity.length >= 2,
      },
    },
  );

  const useMyLocation = async () => {
    setWorking(true);
    setError("");
    try {
      const result = await requestDeviceLocation();
      setLocation(result);
      setLocationSettingsRequired(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to get your location.");
      setLocationSettingsRequired(
        typeof e === "object" && e !== null && "settingsRequired" in e && Boolean(e.settingsRequired),
      );
    } finally {
      setWorking(false);
    }
  };

  const save = () => {
    const parsedAge = Number(age);
    const parsedWeight = Number(weight);
    if (!name.trim()) return setError("Add your name to continue.");
    if (!Number.isInteger(parsedAge) || parsedAge < 18 || parsedAge > 110) {
      return setError("HydraAI is designed for adults. Enter an age from 18 to 110.");
    }
    if (!Number.isFinite(parsedWeight) || parsedWeight < 30 || parsedWeight > 300) {
      return setError("Enter a weight between 30 and 300 kg.");
    }
    const profile: UserProfile = {
      name: name.trim(),
      age: parsedAge,
      weightKg: parsedWeight,
      gender,
      activityLevel,
    };
    finishSetup(profile, location);
    router.replace("/(tabs)");
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <KeyboardAwareScrollViewCompat
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: PlatformTop(insets.top),
          paddingBottom: insets.bottom + 34,
          paddingHorizontal: 22,
          gap: 20,
        }}
        bottomOffset={70}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.brandRow}>
          <View style={[styles.brandIcon, { backgroundColor: colors.primary }]}>
            <Feather name="droplet" size={20} color={colors.primaryForeground} />
          </View>
          <AppText style={{ fontFamily: "Inter_700Bold", fontSize: 16 }}>HydraAI</AppText>
        </View>
        <View style={{ gap: 8 }}>
          <AppText style={styles.title}>A hydration plan that moves with you.</AppText>
          <AppText muted style={{ fontSize: 15, lineHeight: 22 }}>
            A few details help estimate a daily goal around your body, routine, and local weather.
          </AppText>
        </View>

        <Card style={{ gap: 16 }}>
          <AppText style={styles.cardTitle}>Your profile</AppText>
          <Field
            label="First name"
            value={name}
            onChangeText={setName}
            placeholder="What should we call you?"
            autoCapitalize="words"
            returnKeyType="next"
          />
          <View style={{ flexDirection: "row", gap: 12 }}>
            <Field
              label="Age"
              value={age}
              onChangeText={setAge}
              keyboardType="number-pad"
              placeholder="25"
              containerStyle={{ flex: 1 }}
            />
            <Field
              label="Weight (kg)"
              value={weight}
              onChangeText={setWeight}
              keyboardType="decimal-pad"
              placeholder="60"
              containerStyle={{ flex: 1 }}
            />
          </View>
          <View style={{ gap: 8 }}>
            <AppText style={styles.fieldTitle}>Gender</AppText>
            <View style={styles.wrap}>
              {genders.map((option) => (
                <Pill
                  key={option.key}
                  label={option.label}
                  selected={gender === option.key}
                  onPress={() => setGender(option.key)}
                />
              ))}
            </View>
          </View>
          <View style={{ gap: 8 }}>
            <AppText style={styles.fieldTitle}>Typical activity</AppText>
            <View style={styles.wrap}>
              {activityOptions.map((option) => (
                <Pill
                  key={option.key}
                  label={option.label}
                  selected={activityLevel === option.key}
                  onPress={() => setActivityLevel(option.key)}
                />
              ))}
            </View>
          </View>
        </Card>

        <Card style={{ gap: 13 }}>
          <View style={{ gap: 4 }}>
            <AppText style={styles.cardTitle}>Local weather</AppText>
            <AppText muted style={{ fontSize: 13, lineHeight: 19 }}>
              Use location for current conditions, or search for a city. You can skip this for now.
            </AppText>
          </View>
          <ActionButton
            label={working ? "Finding location…" : "Use my current location"}
            icon={working ? <ActivityIndicator color={colors.primaryForeground} /> : <Feather name="crosshair" size={17} color={colors.primaryForeground} />}
            onPress={useMyLocation}
            disabled={working}
          />
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
            <AppText muted style={{ fontSize: 11 }}>OR SEARCH A CITY</AppText>
            <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
          </View>
          <Field
            label="City"
            value={city}
            onChangeText={setCity}
            placeholder="e.g. Hyderabad"
            returnKeyType="search"
            onSubmitEditing={() => setSearchedCity(city.trim())}
          />
          <ActionButton
            label={placeQuery.isFetching ? "Searching…" : "Search city"}
            secondary
            icon={<Feather name="search" size={16} color={colors.secondaryForeground} />}
            onPress={() => setSearchedCity(city.trim())}
            disabled={city.trim().length < 2 || placeQuery.isFetching}
            loading={placeQuery.isFetching}
          />
          {placeQuery.data?.length ? (
            <View style={{ gap: 8 }}>
              {placeQuery.data.map((place, index) => (
                <Pressable
                  key={`${place.name}-${place.country}-${index}`}
                  onPress={() =>
                    setLocation({
                      latitude: place.latitude,
                      longitude: place.longitude,
                      label: [place.name, place.state, place.country].filter(Boolean).join(", "),
                    })
                  }
                  style={({ pressed }) => [
                    styles.place,
                    { borderColor: colors.border, backgroundColor: location?.latitude === place.latitude ? colors.secondary : colors.background, opacity: pressed ? 0.75 : 1 },
                  ]}
                >
                  <Feather name="map-pin" size={16} color={colors.primary} />
                  <AppText style={{ flex: 1, fontSize: 13 }}>
                    {[place.name, place.state, place.country].filter(Boolean).join(", ")}
                  </AppText>
                  {location?.latitude === place.latitude ? <Feather name="check" size={17} color={colors.primary} /> : null}
                </Pressable>
              ))}
            </View>
          ) : null}
          {location ? <InlineNotice>Weather location selected: {location.label}</InlineNotice> : null}
          {locationSettingsRequired ? (
            <ActionButton label="Open device settings" secondary onPress={() => void openDeviceSettings()} />
          ) : null}
          {placeQuery.isError ? <InlineNotice tone="error">Could not search for that city. Check your connection and try again.</InlineNotice> : null}
        </Card>

        {error ? <InlineNotice tone="error">{error}</InlineNotice> : null}
        <ActionButton label="Create my hydration plan" onPress={save} testID="finish-onboarding" />
        <AppText muted style={{ textAlign: "center", fontSize: 11, lineHeight: 17 }}>
          Estimates are general wellness guidance, not medical advice. Ask a clinician about fluid needs if you have a health condition or fluid restriction.
        </AppText>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function PlatformTop(inset: number) {
  return Platform.OS === "web" ? Math.max(inset, 67) : inset + 12;
}

const styles = StyleSheet.create({
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandIcon: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 13 },
  title: { fontSize: 31, lineHeight: 37, fontFamily: "Inter_700Bold", letterSpacing: -1 },
  cardTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  fieldTitle: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  wrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  place: { flexDirection: "row", alignItems: "center", gap: 9, borderWidth: 1, borderRadius: 14, padding: 12 },
});
