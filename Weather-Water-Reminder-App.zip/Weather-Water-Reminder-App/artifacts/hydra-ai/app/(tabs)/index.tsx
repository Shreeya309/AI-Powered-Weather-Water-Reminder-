import React, { useMemo } from "react";
import { Pressable, StyleSheet, View } from "react-native";
import { useRouter } from "expo-router";
import { AppIcon as Feather } from "@/components/AppIcon";
import Svg, { Circle } from "react-native-svg";
import * as Haptics from "expo-haptics";
import {
  getGetCurrentWeatherQueryKey,
  useCreateHydrationInsight,
  useGetCurrentWeather,
} from "@workspace/api-client-react";
import { ActionButton, AppText, Card, InlineNotice, Page, PageHeading, SectionHeading } from "@/components/Kit";
import { useHydration } from "@/context/HydrationContext";
import { calculateDailyGoal, calculateStreak, formatHour, formatVolume, getNextReminder, isToday } from "@/lib/hydration";
import { useColors } from "@/hooks/useColors";

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { profile, location, logs, reminders, addWater, storageError } = useHydration();
  const weatherQuery = useGetCurrentWeather(
    { lat: location?.latitude ?? 0, lon: location?.longitude ?? 0 },
    {
      query: {
        queryKey: getGetCurrentWeatherQueryKey({ lat: location?.latitude ?? 0, lon: location?.longitude ?? 0 }),
        enabled: !!location,
        staleTime: 10 * 60 * 1000,
        refetchInterval: 20 * 60 * 1000,
      },
    },
  );
  const weather = weatherQuery.data;
  const todayLogs = useMemo(() => logs.filter((log) => isToday(log.createdAt)), [logs]);
  const consumedMl = todayLogs.reduce((sum, log) => sum + log.amountMl, 0);
  const goalMl = calculateDailyGoal(profile, weather);
  const progress = Math.min(consumedMl / goalMl, 1);
  const remaining = Math.max(goalMl - consumedMl, 0);
  const insightMutation = useCreateHydrationInsight();
  const streak = calculateStreak(logs, goalMl);

  const requestInsight = () => {
    if (!profile || !weather) return;
    insightMutation.mutate({
      data: {
        age: profile.age,
        weightKg: profile.weightKg,
        gender: profile.gender,
        activityLevel: profile.activityLevel,
        temperatureC: weather.temperatureC,
        humidityPercent: weather.humidityPercent,
        uvIndex: weather.uvIndex,
        goalMl,
        consumedMl,
      },
    });
  };

  const logWater = (amount: number) => {
    addWater(amount);
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const now = new Date();
  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 18 ? "Good afternoon" : "Good evening";
  const weatherIcon =
    weather?.iconCode?.startsWith("09") || weather?.iconCode?.startsWith("10")
      ? "cloud-drizzle"
      : weather?.iconCode?.startsWith("02") || weather?.iconCode?.startsWith("03") || weather?.iconCode?.startsWith("04")
        ? "cloud"
        : "sun";

  return (
    <Page>
      <PageHeading
        eyebrow="HydraAI · TODAY"
        title={`${greeting}${profile?.name ? `, ${profile.name.split(" ")[0]}` : ""}`}
        subtitle={now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
        trailing={
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open profile"
            onPress={() => router.push("/(tabs)/profile")}
            style={({ pressed }) => [styles.profileButton, { backgroundColor: colors.secondary, opacity: pressed ? 0.7 : 1 }]}
          >
            <Feather name="user" size={19} color={colors.primary} />
          </Pressable>
        }
      />

      {storageError ? <InlineNotice tone="error">{storageError}</InlineNotice> : null}

      <Card style={[styles.goalCard, { backgroundColor: colors.deepSurface, borderColor: colors.deepSurface }]}>
        <View style={styles.goalTop}>
          <View>
            <AppText style={{ color: colors.deepForeground, fontSize: 13, fontFamily: "Inter_600SemiBold" }}>TODAY'S WATER PLAN</AppText>
            <AppText style={{ color: colors.deepSubtle, fontSize: 12, marginTop: 4 }}>
              {weather ? "Adjusted for your profile and local conditions" : "Your personal daily estimate"}
            </AppText>
          </View>
          <View style={[styles.goalIcon, { backgroundColor: colors.primary }]}>
            <Feather name="droplet" size={16} color={colors.primaryForeground} />
          </View>
        </View>
        <View style={styles.goalMiddle}>
          <View style={{ flex: 1, gap: 5 }}>
            <AppText style={{ color: colors.deepForeground, fontSize: 45, lineHeight: 52, fontFamily: "Inter_700Bold", letterSpacing: -1.5 }}>
              {formatVolume(consumedMl)}
            </AppText>
            <AppText style={{ color: colors.deepSubtle, fontSize: 14 }}>
              of {formatVolume(goalMl)} daily goal
            </AppText>
            <AppText style={{ color: colors.primarySoft, fontSize: 13, fontFamily: "Inter_600SemiBold", marginTop: 4 }}>
              {remaining === 0 ? "Daily goal reached" : `${formatVolume(remaining)} to go`}
            </AppText>
          </View>
          <View style={styles.ringWrap}>
            <Svg width={128} height={128} viewBox="0 0 128 128">
              <Circle cx="64" cy="64" r="53" stroke={colors.ringTrack} strokeWidth="8" fill="none" />
              <Circle
                cx="64"
                cy="64"
                r="53"
                stroke={colors.primarySoft}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={Math.PI * 106}
                strokeDashoffset={Math.PI * 106 * (1 - progress)}
                rotation="-90"
                origin="64, 64"
                fill="none"
              />
            </Svg>
            <View style={styles.ringCenter}>
              <AppText style={{ color: colors.deepForeground, fontSize: 26, fontFamily: "Inter_700Bold" }}>
                {Math.round(progress * 100)}%
              </AppText>
              <AppText style={{ color: colors.deepSubtle, fontSize: 10 }}>complete</AppText>
            </View>
          </View>
        </View>
        <View style={[styles.goalFoot, { borderTopColor: colors.deepLine }]}>
          <View style={styles.goalFootItem}>
            <Feather name="activity" size={15} color={colors.primarySoft} />
            <AppText style={{ color: colors.deepForeground, fontSize: 12 }}>
              {streak} day streak
            </AppText>
          </View>
          <AppText style={{ color: colors.deepSubtle, fontSize: 12 }}>
            {todayLogs.length} {todayLogs.length === 1 ? "drink" : "drinks"} logged
          </AppText>
        </View>
      </Card>

      <View style={{ gap: 11 }}>
        <SectionHeading title="Log a drink" trailing={<AppText muted style={{ fontSize: 12 }}>Tap to add</AppText>} />
        <View style={styles.quickRow}>
          {[150, 250, 500].map((amount) => (
            <Pressable
              key={amount}
              testID={`log-water-${amount}`}
              accessibilityRole="button"
              onPress={() => logWater(amount)}
              style={({ pressed }) => [
                styles.quickButton,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.72 : 1 },
              ]}
            >
              <View style={[styles.quickIcon, { backgroundColor: colors.secondary }]}>
                <Feather name="plus" size={16} color={colors.primary} />
              </View>
              <AppText style={{ fontSize: 15, fontFamily: "Inter_600SemiBold" }}>+{amount}</AppText>
              <AppText muted style={{ fontSize: 11 }}>ml</AppText>
            </Pressable>
          ))}
        </View>
      </View>

      <Card style={styles.weatherCard}>
        <View style={[styles.weatherIcon, { backgroundColor: colors.sunTint }]}>
          {weatherQuery.isLoading ? (
            <Feather name="loader" size={20} color={colors.primary} />
          ) : (
            <Feather name={weatherIcon as "sun"} size={20} color={colors.sun} />
          )}
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <AppText style={{ fontSize: 15, fontFamily: "Inter_600SemiBold" }}>
            {weather ? `${weather.location}${weather.country ? `, ${weather.country}` : ""}` : location?.label ?? "Weather-aware plan"}
          </AppText>
          <AppText muted style={{ fontSize: 12, lineHeight: 18 }}>
            {weather
              ? `${Math.round(weather.temperatureC)}°C · ${weather.humidityPercent}% humidity${weather.uvIndex !== null ? ` · UV ${weather.uvIndex.toFixed(0)}` : ""}`
              : weatherQuery.isError
                ? "Live weather is unavailable. Your baseline goal is still ready."
                : location
                  ? "Checking current local conditions…"
                  : "Add your location to adjust your plan to local weather."}
          </AppText>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Refresh weather"
          onPress={() => (location ? void weatherQuery.refetch() : router.push("/(tabs)/profile"))}
          style={({ pressed }) => [styles.weatherAction, { backgroundColor: colors.secondary, opacity: pressed ? 0.72 : 1 }]}
        >
          <Feather name={location ? "refresh-cw" : "map-pin"} size={16} color={colors.primary} />
        </Pressable>
      </Card>

      <Card style={{ gap: 13 }}>
        <View style={styles.insightHeader}>
          <View style={[styles.aiIcon, { backgroundColor: colors.aiTint }]}>
            <Feather name="star" size={17} color={colors.aiAccent} />
          </View>
          <View style={{ flex: 1 }}>
            <AppText style={{ fontSize: 15, fontFamily: "Inter_600SemiBold" }}>Your daily insight</AppText>
            <AppText muted style={{ fontSize: 11, marginTop: 2 }}>AI guidance based on today's conditions</AppText>
          </View>
        </View>
        {insightMutation.data ? (
          <AppText style={{ fontSize: 14, lineHeight: 21 }}>{insightMutation.data.message}</AppText>
        ) : (
          <AppText muted style={{ fontSize: 13, lineHeight: 20 }}>
            Get one practical hydration tip shaped around your weather, activity, and progress.
          </AppText>
        )}
        {insightMutation.isError ? (
          <InlineNotice tone="error">Could not create a tip right now. Please try again in a moment.</InlineNotice>
        ) : null}
        <ActionButton
          label={insightMutation.isPending ? "Thinking…" : insightMutation.data ? "Refresh tip" : "Get today's tip"}
          icon={<Feather name="star" size={16} color={colors.primaryForeground} />}
          onPress={requestInsight}
          disabled={!weather}
          loading={insightMutation.isPending}
          testID="generate-ai-insight"
        />
        {!weather ? (
          <AppText muted style={{ fontSize: 11, textAlign: "center" }}>
            {location ? "Waiting for live weather to personalize your tip." : "Choose a location to get a weather-aware tip."}
          </AppText>
        ) : null}
      </Card>

      <Card style={{ gap: 12 }}>
        <View style={styles.scheduleHeader}>
          <View style={{ gap: 3 }}>
            <AppText style={{ fontSize: 15, fontFamily: "Inter_600SemiBold" }}>Your reminder rhythm</AppText>
            <AppText muted style={{ fontSize: 12 }}>
              {reminders.enabled
                ? `Every ${reminders.intervalHours}h · ${formatHour(reminders.wakeHour)}–${formatHour(reminders.sleepHour)}`
                : "Reminders are paused"}
            </AppText>
          </View>
          <Pressable accessibilityRole="button" onPress={() => router.push("/(tabs)/reminders")}>
            <AppText style={{ color: colors.primary, fontSize: 12, fontFamily: "Inter_600SemiBold" }}>Manage</AppText>
          </Pressable>
        </View>
        {reminders.enabled ? (
          <View style={[styles.nextReminder, { backgroundColor: colors.secondary }]}>
            <Feather name="bell" size={16} color={colors.primary} />
            <AppText style={{ fontSize: 12 }}>
              Next reminder · {formatHour(getNextReminder(reminders))}
            </AppText>
          </View>
        ) : (
          <ActionButton
            label="Set my reminders"
            secondary
            icon={<Feather name="bell" size={16} color={colors.secondaryForeground} />}
            onPress={() => router.push("/(tabs)/reminders")}
          />
        )}
      </Card>
    </Page>
  );
}

const styles = StyleSheet.create({
  profileButton: { width: 42, height: 42, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  goalCard: { padding: 20, gap: 18 },
  goalTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  goalIcon: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 12 },
  goalMiddle: { flexDirection: "row", alignItems: "center", gap: 12, minHeight: 142 },
  ringWrap: { width: 128, height: 128, alignItems: "center", justifyContent: "center" },
  ringCenter: { position: "absolute", alignItems: "center", gap: 0 },
  goalFoot: { borderTopWidth: 1, paddingTop: 13, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  goalFootItem: { flexDirection: "row", alignItems: "center", gap: 7 },
  quickRow: { flexDirection: "row", gap: 10 },
  quickButton: { flex: 1, minHeight: 90, borderRadius: 19, borderWidth: 1, alignItems: "center", justifyContent: "center", gap: 5 },
  quickIcon: { width: 28, height: 28, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  weatherCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  weatherIcon: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  weatherAction: { width: 36, height: 36, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  insightHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  aiIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  scheduleHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  nextReminder: { flexDirection: "row", alignItems: "center", gap: 9, borderRadius: 13, padding: 12 },
});
