import React, { useState } from "react";
import { Alert, Linking, Platform, Pressable, StyleSheet, Switch, View } from "react-native";
import { AppIcon as Feather } from "@/components/AppIcon";
import * as Notifications from "expo-notifications";
import { ActionButton, AppText, Card, InlineNotice, Page, PageHeading, SectionHeading } from "@/components/Kit";
import { useHydration } from "@/context/HydrationContext";
import { formatHour } from "@/lib/hydration";
import { useColors } from "@/hooks/useColors";

export default function RemindersScreen() {
  const colors = useColors();
  const { reminders, setReminderSettings } = useHydration();
  const [busy, setBusy] = useState(false);
  const [permissionMessage, setPermissionMessage] = useState("");
  const [settingsRequired, setSettingsRequired] = useState(false);
  const hours = Array.from(
    { length: Math.ceil((reminders.sleepHour - reminders.wakeHour) / reminders.intervalHours) },
    (_, index) => reminders.wakeHour + index * reminders.intervalHours,
  ).filter((hour) => hour < reminders.sleepHour);

  const update = async (patch: Partial<typeof reminders>) => {
    setBusy(true);
    setPermissionMessage("");
    try {
      const ok = await setReminderSettings({ ...reminders, ...patch });
      if (!ok) {
        setPermissionMessage("Notifications are turned off for HydraAI. Enable them in device settings to receive reminders.");
        if (Platform.OS !== "web") {
          const permission = await Notifications.getPermissionsAsync();
          setSettingsRequired(!permission.granted && !permission.canAskAgain);
        }
      } else {
        setSettingsRequired(false);
      }
    } catch {
      setPermissionMessage("Reminders could not be scheduled. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Page>
      <PageHeading eyebrow="GENTLE NUDGES" title="Reminders" subtitle="Choose a rhythm that fits your day." />

      <Card style={styles.toggleCard}>
        <View style={[styles.bellIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="bell" size={19} color={colors.primary} />
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <AppText style={{ fontSize: 15, fontFamily: "Inter_600SemiBold" }}>Water reminders</AppText>
          <AppText muted style={{ fontSize: 12, lineHeight: 18 }}>
            {reminders.enabled ? "On · a small nudge during your waking hours" : "Off · turn on whenever you're ready"}
          </AppText>
        </View>
        <Switch
          testID="reminder-toggle"
          value={reminders.enabled}
          onValueChange={(enabled) => void update({ enabled })}
          disabled={busy}
          trackColor={{ false: colors.border, true: colors.primarySoft }}
          thumbColor={reminders.enabled ? colors.primary : colors.card}
          accessibilityLabel="Toggle hydration reminders"
        />
      </Card>

      {permissionMessage ? <InlineNotice tone="error">{permissionMessage}</InlineNotice> : null}
      {settingsRequired ? (
        <ActionButton
          label="Open device settings"
          secondary
          onPress={async () => {
            try {
              await Linking.openSettings();
            } catch {
              Alert.alert("Settings unavailable", "Open your device settings to allow notifications for HydraAI.");
            }
          }}
        />
      ) : null}
      {Platform.OS === "web" ? (
        <InlineNotice>
          This preview stores your schedule. Scheduled alerts are delivered by HydraAI on your iOS or Android device.
        </InlineNotice>
      ) : null}

      <Card style={{ gap: 17 }}>
        <SectionHeading title="Timing" />
        <View style={styles.settingRow}>
          <View style={{ flex: 1, gap: 4 }}>
            <AppText style={{ fontSize: 14, fontFamily: "Inter_600SemiBold" }}>Remind me every</AppText>
            <AppText muted style={{ fontSize: 12 }}>More space between reminders means fewer nudges.</AppText>
          </View>
          <View style={[styles.stepper, { backgroundColor: colors.secondary }]}>
            <StepButton
              label="Decrease reminder frequency"
              icon="minus"
              onPress={() => void update({ intervalHours: Math.max(1, reminders.intervalHours - 1) })}
              disabled={reminders.intervalHours <= 1 || busy}
              colors={colors}
            />
            <AppText style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", minWidth: 31, textAlign: "center" }}>
              {reminders.intervalHours}h
            </AppText>
            <StepButton
              label="Increase reminder frequency"
              icon="plus"
              onPress={() => void update({ intervalHours: Math.min(4, reminders.intervalHours + 1) })}
              disabled={reminders.intervalHours >= 4 || busy}
              colors={colors}
            />
          </View>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.settingRow}>
          <View style={{ flex: 1, gap: 4 }}>
            <AppText style={{ fontSize: 14, fontFamily: "Inter_600SemiBold" }}>Wake-up time</AppText>
            <AppText muted style={{ fontSize: 12 }}>First reminder window</AppText>
          </View>
          <View style={[styles.stepper, { backgroundColor: colors.secondary }]}>
            <StepButton
              label="Earlier wake-up"
              icon="minus"
              onPress={() => void update({ wakeHour: Math.max(5, reminders.wakeHour - 1) })}
              disabled={reminders.wakeHour <= 5 || busy}
              colors={colors}
            />
            <AppText style={{ fontSize: 12, fontFamily: "Inter_600SemiBold" }}>{formatHour(reminders.wakeHour)}</AppText>
            <StepButton
              label="Later wake-up"
              icon="plus"
              onPress={() => void update({ wakeHour: Math.min(reminders.sleepHour - 4, reminders.wakeHour + 1) })}
              disabled={reminders.wakeHour >= reminders.sleepHour - 4 || busy}
              colors={colors}
            />
          </View>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.settingRow}>
          <View style={{ flex: 1, gap: 4 }}>
            <AppText style={{ fontSize: 14, fontFamily: "Inter_600SemiBold" }}>Quiet time starts</AppText>
            <AppText muted style={{ fontSize: 12 }}>No scheduled nudges after this time</AppText>
          </View>
          <View style={[styles.stepper, { backgroundColor: colors.secondary }]}>
            <StepButton
              label="Earlier quiet time"
              icon="minus"
              onPress={() => void update({ sleepHour: Math.max(reminders.wakeHour + 4, reminders.sleepHour - 1) })}
              disabled={reminders.sleepHour <= reminders.wakeHour + 4 || busy}
              colors={colors}
            />
            <AppText style={{ fontSize: 12, fontFamily: "Inter_600SemiBold" }}>{formatHour(reminders.sleepHour)}</AppText>
            <StepButton
              label="Later quiet time"
              icon="plus"
              onPress={() => void update({ sleepHour: Math.min(24, reminders.sleepHour + 1) })}
              disabled={reminders.sleepHour >= 24 || busy}
              colors={colors}
            />
          </View>
        </View>
      </Card>

      <Card style={{ gap: 15 }}>
        <View style={{ gap: 4 }}>
          <SectionHeading title="Today's schedule" />
          <AppText muted style={{ fontSize: 12 }}>
            {reminders.enabled ? `${hours.length} reminders · local time` : "Turn reminders on to schedule these times"}
          </AppText>
        </View>
        {hours.length ? (
          hours.map((hour, index) => (
            <View key={hour} style={styles.scheduleRow}>
              <AppText muted style={{ width: 68, fontSize: 12 }}>{formatHour(hour)}</AppText>
              <View style={[styles.timelineTrack, { backgroundColor: colors.secondary }]}>
                <View style={[styles.timelineFill, { backgroundColor: colors.primary, width: `${Math.max(24, 90 - index * 7)}%` }]} />
              </View>
              <AppText style={{ width: 30, textAlign: "right", fontSize: 11, fontFamily: "Inter_600SemiBold" }}>{index + 1}</AppText>
            </View>
          ))
        ) : (
          <AppText muted style={{ fontSize: 12 }}>Your reminder times will appear here.</AppText>
        )}
      </Card>

      <Card style={{ gap: 10, backgroundColor: colors.secondary, borderColor: colors.secondary }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 9 }}>
          <Feather name="heart" size={16} color={colors.primary} />
          <AppText style={{ fontSize: 13, fontFamily: "Inter_600SemiBold" }}>Keep it comfortable</AppText>
        </View>
        <AppText muted style={{ fontSize: 12, lineHeight: 19 }}>
          Reminders are gentle prompts, not instructions. Skip one whenever you don't need a drink.
        </AppText>
      </Card>

      {busy ? <ActionButton label="Updating schedule…" loading disabled onPress={() => undefined} /> : null}
    </Page>
  );
}

function StepButton({
  label,
  icon,
  onPress,
  disabled,
  colors,
}: {
  label: string;
  icon: "plus" | "minus";
  onPress: () => void;
  disabled: boolean;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.stepButton, { opacity: disabled ? 0.35 : pressed ? 0.65 : 1 }]}
    >
      <Feather name={icon} size={14} color={colors.primary} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  toggleCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 15 },
  bellIcon: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  settingRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  stepper: { minHeight: 39, flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 14, paddingHorizontal: 5 },
  stepButton: { width: 29, height: 29, alignItems: "center", justifyContent: "center" },
  divider: { height: StyleSheet.hairlineWidth },
  scheduleRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  timelineTrack: { height: 8, flex: 1, borderRadius: 8, overflow: "hidden" },
  timelineFill: { height: "100%", borderRadius: 8 },
});
