import React, { useState } from "react";
import { ActivityIndicator, Platform, StyleSheet, View } from "react-native";
import { useRouter } from "expo-router";
import { AppIcon as Feather } from "@/components/AppIcon";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { ActionButton, AppText, Card, Field, InlineNotice, Pill } from "@/components/Kit";
import { useHydration } from "@/context/HydrationContext";
import { openDeviceSettings, requestDeviceLocation } from "@/lib/location";
import type { ActivityLevel, Gender, UserProfile } from "@/lib/hydration";
import { useColors } from "@/hooks/useColors";
import { getSearchWeatherLocationsQueryKey, useSearchWeatherLocations } from "@workspace/api-client-react";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const genders: { key: Gender; label: string }[] = [
  { key: "woman", label: "Woman" },
  { key: "man", label: "Man" },
  { key: "nonbinary", label: "Non-binary" },
  { key: "undisclosed", label: "Prefer not to say" },
];
const activities: { key: ActivityLevel; label: string }[] = [
  { key: "low", label: "Light" },
  { key: "moderate", label: "Moderate" },
  { key: "high", label: "Active" },
];

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { profile, location, saveProfile, saveLocation, reminders } = useHydration();
  const [name, setName] = useState(profile?.name ?? "");
  const [age, setAge] = useState(String(profile?.age ?? 25));
  const [weight, setWeight] = useState(String(profile?.weightKg ?? 60));
  const [gender, setGender] = useState<Gender>(profile?.gender ?? "undisclosed");
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(profile?.activityLevel ?? "moderate");
  const [city, setCity] = useState("");
  const [searchedCity, setSearchedCity] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [findingLocation, setFindingLocation] = useState(false);
  const [locationSettingsRequired, setLocationSettingsRequired] = useState(false);
  const placeQuery = useSearchWeatherLocations(
    { city: searchedCity },
    {
      query: {
        queryKey: getSearchWeatherLocationsQueryKey({ city: searchedCity }),
        enabled: searchedCity.length >= 2,
      },
    },
  );

  const save = () => {
    const parsedAge = Number(age);
    const parsedWeight = Number(weight);
    if (!name.trim()) return setError("Add your name before saving.");
    if (!Number.isInteger(parsedAge) || parsedAge < 18 || parsedAge > 110) {
      return setError("Enter an age from 18 to 110.");
    }
    if (!Number.isFinite(parsedWeight) || parsedWeight < 30 || parsedWeight > 300) {
      return setError("Enter a weight between 30 and 300 kg.");
    }
    const nextProfile: UserProfile = {
      name: name.trim(),
      age: parsedAge,
      weightKg: parsedWeight,
      gender,
      activityLevel,
    };
    saveProfile(nextProfile);
    setError("");
    setSaved(true);
  };

  const useMyLocation = async () => {
    setFindingLocation(true);
    setError("");
    try {
      saveLocation(await requestDeviceLocation());
      setLocationSettingsRequired(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to get your location.");
      setLocationSettingsRequired(
        typeof e === "object" && e !== null && "settingsRequired" in e && Boolean(e.settingsRequired),
      );
    } finally {
      setFindingLocation(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <KeyboardAwareScrollViewCompat
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
          paddingBottom: Platform.OS === "web" ? 122 : insets.bottom + 44,
          paddingHorizontal: 22,
          gap: 18,
        }}
        bottomOffset={70}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={{ gap: 4 }}>
          <AppText style={styles.eyebrow}>YOUR DETAILS</AppText>
          <AppText style={styles.title}>Profile</AppText>
          <AppText muted style={{ fontSize: 14, lineHeight: 20 }}>
            Update your details to keep your plan relevant.
          </AppText>
        </View>

        <Card style={{ gap: 15 }}>
          <Field label="First name" value={name} onChangeText={setName} placeholder="Name" autoCapitalize="words" />
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Field label="Age" value={age} onChangeText={setAge} keyboardType="number-pad" placeholder="25" containerStyle={{ flex: 1 }} />
            <Field label="Weight (kg)" value={weight} onChangeText={setWeight} keyboardType="decimal-pad" placeholder="60" containerStyle={{ flex: 1 }} />
          </View>
          <View style={{ gap: 8 }}>
            <AppText style={styles.label}>Gender</AppText>
            <View style={styles.wrap}>
              {genders.map((option) => (
                <Pill key={option.key} label={option.label} selected={gender === option.key} onPress={() => setGender(option.key)} />
              ))}
            </View>
          </View>
          <View style={{ gap: 8 }}>
            <AppText style={styles.label}>Typical activity</AppText>
            <View style={styles.wrap}>
              {activities.map((option) => (
                <Pill key={option.key} label={option.label} selected={activityLevel === option.key} onPress={() => setActivityLevel(option.key)} />
              ))}
            </View>
          </View>
          <ActionButton label={saved ? "Profile saved" : "Save profile"} onPress={save} icon={<Feather name={saved ? "check" : "save"} size={16} color={colors.primaryForeground} />} />
        </Card>

        <Card style={{ gap: 8, backgroundColor: colors.secondary, borderColor: colors.secondary }}>
          <AppText style={{ fontSize: 14, fontFamily: "Inter_600SemiBold" }}>How your daily target is estimated</AppText>
          <AppText muted style={{ fontSize: 12, lineHeight: 19 }}>
            HydraAI starts with roughly 30 ml per kg of body weight, then adjusts for your activity and—when available—heat, humidity, and UV. It is a wellness estimate, not a medical prescription.
          </AppText>
        </Card>

        <Card style={{ gap: 13 }}>
          <View style={{ gap: 4 }}>
            <AppText style={{ fontSize: 16, fontFamily: "Inter_600SemiBold" }}>Weather location</AppText>
            <AppText muted style={{ fontSize: 12, lineHeight: 18 }}>
              {location ? `Current: ${location.label}` : "Set a location for live temperature, humidity, and UV adjustments."}
            </AppText>
          </View>
          <ActionButton
            label={findingLocation ? "Finding location…" : "Use my current location"}
            icon={findingLocation ? <ActivityIndicator color={colors.primaryForeground} /> : <Feather name="crosshair" size={16} color={colors.primaryForeground} />}
            onPress={useMyLocation}
            disabled={findingLocation}
          />
          {locationSettingsRequired ? (
            <ActionButton label="Open device settings" secondary onPress={() => void openDeviceSettings()} />
          ) : null}
          <Field
            label="Search another city"
            value={city}
            onChangeText={setCity}
            placeholder="e.g. Hyderabad"
            returnKeyType="search"
            onSubmitEditing={() => setSearchedCity(city.trim())}
          />
          <ActionButton
            label={placeQuery.isFetching ? "Searching…" : "Search"}
            secondary
            icon={<Feather name="search" size={16} color={colors.secondaryForeground} />}
            onPress={() => setSearchedCity(city.trim())}
            disabled={city.trim().length < 2 || placeQuery.isFetching}
            loading={placeQuery.isFetching}
          />
          {placeQuery.data?.map((place, index) => (
            <ActionButton
              key={`${place.name}-${place.country}-${index}`}
              label={[place.name, place.state, place.country].filter(Boolean).join(", ")}
              secondary
              icon={<Feather name="map-pin" size={15} color={colors.secondaryForeground} />}
              onPress={() => {
                saveLocation({
                  latitude: place.latitude,
                  longitude: place.longitude,
                  label: [place.name, place.state, place.country].filter(Boolean).join(", "),
                });
                setSearchedCity("");
                setCity("");
              }}
            />
          ))}
          {location ? (
            <ActionButton
              label="Remove weather location"
              secondary
              icon={<Feather name="x" size={16} color={colors.secondaryForeground} />}
              onPress={() => saveLocation(null)}
            />
          ) : null}
          {placeQuery.isError ? <InlineNotice tone="error">Could not find that city. Check your connection and try again.</InlineNotice> : null}
        </Card>

        <Card style={{ gap: 11 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 9 }}>
            <Feather name="bell" size={16} color={colors.primary} />
            <AppText style={{ fontSize: 14, fontFamily: "Inter_600SemiBold" }}>Reminder status</AppText>
          </View>
          <AppText muted style={{ fontSize: 12, lineHeight: 18 }}>
            {reminders.enabled ? `Every ${reminders.intervalHours} hours during your waking window.` : "No scheduled reminders right now."}
          </AppText>
          <ActionButton label="Manage reminders" secondary onPress={() => router.push("/(tabs)/reminders")} />
        </Card>

        <Card style={{ gap: 8, backgroundColor: colors.secondary, borderColor: colors.secondary }}>
          <AppText style={{ fontSize: 13, fontFamily: "Inter_600SemiBold" }}>Your data stays on this device</AppText>
          <AppText muted style={{ fontSize: 12, lineHeight: 18 }}>
            Profile and drink logs are stored locally. Weather requests use your coordinates; AI tips receive your hydration context only when you request a tip.
          </AppText>
        </Card>

        {error ? <InlineNotice tone="error">{error}</InlineNotice> : null}
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  eyebrow: { fontSize: 10, letterSpacing: 1.6, fontFamily: "Inter_600SemiBold" },
  title: { fontSize: 28, fontFamily: "Inter_700Bold" },
  label: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  wrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
});
