import React, { useMemo } from "react";
import { StyleSheet, View } from "react-native";
import { AppIcon as Feather } from "@/components/AppIcon";
import { getGetCurrentWeatherQueryKey, useGetCurrentWeather } from "@workspace/api-client-react";
import { AppText, Card, Page, PageHeading, SectionHeading } from "@/components/Kit";
import { useHydration } from "@/context/HydrationContext";
import { calculateDailyGoal, calculateStreak, formatVolume, isToday, localDayKey } from "@/lib/hydration";
import { useColors } from "@/hooks/useColors";

export default function ProgressScreen() {
  const colors = useColors();
  const { profile, location, logs } = useHydration();
  const weatherQuery = useGetCurrentWeather(
    { lat: location?.latitude ?? 0, lon: location?.longitude ?? 0 },
    {
      query: {
        queryKey: getGetCurrentWeatherQueryKey({ lat: location?.latitude ?? 0, lon: location?.longitude ?? 0 }),
        enabled: !!location,
        staleTime: 10 * 60 * 1000,
      },
    },
  );
  const goalMl = calculateDailyGoal(profile, weatherQuery.data);
  const todayTotal = logs.filter((log) => isToday(log.createdAt)).reduce((sum, log) => sum + log.amountMl, 0);
  const week = useMemo(
    () =>
      Array.from({ length: 7 }, (_, index) => {
        const date = new Date();
        date.setDate(date.getDate() - (6 - index));
        const key = localDayKey(date);
        const amount = logs
          .filter((log) => localDayKey(new Date(log.createdAt)) === key)
          .reduce((sum, log) => sum + log.amountMl, 0);
        return {
          key,
          day: date.toLocaleDateString("en-US", { weekday: "short" }),
          amount,
          today: index === 6,
        };
      }),
    [logs],
  );
  const weekTotal = week.reduce((sum, day) => sum + day.amount, 0);
  const completedDays = week.filter((day) => day.amount >= goalMl).length;
  const totalEntries = logs.length;
  const streak = calculateStreak(logs, goalMl);

  return (
    <Page>
      <PageHeading eyebrow="YOUR HISTORY" title="Progress" subtitle="Small sips add up over time." />

      <View style={styles.statsRow}>
        <Card style={[styles.statCard, { backgroundColor: colors.secondary, borderColor: colors.secondary }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.card }]}>
            <Feather name="zap" size={16} color={colors.sun} />
          </View>
          <AppText style={styles.statValue}>{streak}</AppText>
          <AppText muted style={styles.statLabel}>day streak</AppText>
        </Card>
        <Card style={[styles.statCard, { backgroundColor: colors.secondary, borderColor: colors.secondary }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.card }]}>
            <Feather name="check-circle" size={16} color={colors.primary} />
          </View>
          <AppText style={styles.statValue}>{completedDays}<AppText style={{ fontSize: 15 }}> / 7</AppText></AppText>
          <AppText muted style={styles.statLabel}>goals reached</AppText>
        </Card>
        <Card style={[styles.statCard, { backgroundColor: colors.secondary, borderColor: colors.secondary }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.card }]}>
            <Feather name="droplet" size={16} color={colors.primary} />
          </View>
          <AppText style={styles.statValue}>{formatVolume(Math.round(weekTotal / 7))}</AppText>
          <AppText muted style={styles.statLabel}>daily average</AppText>
        </Card>
      </View>

      <Card style={{ gap: 18 }}>
        <View style={{ gap: 4 }}>
          <SectionHeading title="Weekly hydration" />
          <AppText muted style={{ fontSize: 12 }}>Past 7 days · target {formatVolume(goalMl)} per day</AppText>
        </View>
        <View style={styles.chart}>
          {week.map((day) => {
            const height = Math.max(day.amount > 0 ? 5 : 2, Math.min(day.amount / goalMl, 1.15) * 104);
            const metGoal = day.amount >= goalMl;
            return (
              <View key={day.key} style={styles.barItem}>
                <AppText style={{ color: colors.mutedForeground, fontSize: 9 }}>
                  {day.amount > 0 ? (day.amount >= 1000 ? `${(day.amount / 1000).toFixed(1)}` : `${day.amount}`) : ""}
                </AppText>
                <View style={[styles.barTrack, { backgroundColor: colors.secondary }]}>
                  <View
                    style={[
                      styles.bar,
                      {
                        height,
                        backgroundColor: metGoal ? colors.primary : day.amount > 0 ? colors.primarySoft : "transparent",
                      },
                    ]}
                  />
                </View>
                <AppText style={{ color: day.today ? colors.primary : colors.mutedForeground, fontSize: 10, fontFamily: day.today ? "Inter_600SemiBold" : "Inter_400Regular" }}>
                  {day.day}
                </AppText>
              </View>
            );
          })}
        </View>
        {weekTotal === 0 ? (
          <AppText muted style={{ fontSize: 12, lineHeight: 18, textAlign: "center" }}>
            Your weekly trend will appear here as you log drinks.
          </AppText>
        ) : null}
      </Card>

      <Card style={{ gap: 14 }}>
        <SectionHeading title="Achievements" trailing={<AppText muted style={{ fontSize: 11 }}>{(totalEntries > 0 ? 1 : 0) + (streak >= 3 ? 1 : 0) + (streak >= 7 ? 1 : 0)} / 3</AppText>} />
        <Achievement
          icon="droplet"
          title="First drop"
          detail="Log your first drink"
          unlocked={totalEntries > 0}
          colors={colors}
        />
        <Achievement
          icon="zap"
          title="Hydro habit"
          detail="Reach your goal 3 days in a row"
          unlocked={streak >= 3}
          colors={colors}
        />
        <Achievement
          icon="award"
          title="Week warrior"
          detail="Reach your goal 7 days in a row"
          unlocked={streak >= 7}
          colors={colors}
        />
      </Card>

      <Card style={{ gap: 13 }}>
        <SectionHeading title="Today's drinks" trailing={<AppText muted style={{ fontSize: 12 }}>{formatVolume(todayTotal)}</AppText>} />
        {logs.filter((log) => isToday(log.createdAt)).length ? (
          logs.filter((log) => isToday(log.createdAt)).slice(0, 6).map((log) => (
            <View key={log.id} style={[styles.logRow, { borderBottomColor: colors.border }]}>
              <View style={[styles.logIcon, { backgroundColor: colors.secondary }]}>
                <Feather name="droplet" size={15} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <AppText style={{ fontSize: 13, fontFamily: "Inter_600SemiBold" }}>{formatVolume(log.amountMl)}</AppText>
                <AppText muted style={{ fontSize: 11, marginTop: 2 }}>
                  {new Date(log.createdAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                </AppText>
              </View>
            </View>
          ))
        ) : (
          <View style={{ alignItems: "center", gap: 7, paddingVertical: 10 }}>
            <Feather name="coffee" size={20} color={colors.mutedForeground} />
            <AppText muted style={{ fontSize: 12 }}>No drinks logged yet today.</AppText>
          </View>
        )}
      </Card>
      <AppText muted style={{ textAlign: "center", fontSize: 11, lineHeight: 17 }}>
        A goal reached is a guide, not a reason to drink beyond your needs. Daily targets are estimates.
      </AppText>
    </Page>
  );
}

function Achievement({
  icon,
  title,
  detail,
  unlocked,
  colors,
}: {
  icon: React.ComponentProps<typeof Feather>["name"];
  title: string;
  detail: string;
  unlocked: boolean;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={styles.achievement}>
      <View style={[styles.achievementIcon, { backgroundColor: unlocked ? colors.aiTint : colors.secondary }]}>
        <Feather name={unlocked ? icon : "lock"} size={16} color={unlocked ? colors.aiAccent : colors.mutedForeground} />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <AppText style={{ fontSize: 13, fontFamily: "Inter_600SemiBold" }}>{title}</AppText>
        <AppText muted style={{ fontSize: 11 }}>{detail}</AppText>
      </View>
      {unlocked ? <Feather name="check" size={16} color={colors.primary} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: "row", gap: 8 },
  statCard: { flex: 1, minHeight: 116, padding: 12, gap: 5 },
  statIcon: { width: 28, height: 28, alignItems: "center", justifyContent: "center", borderRadius: 10, marginBottom: 2 },
  statValue: { fontSize: 17, fontFamily: "Inter_700Bold" },
  statLabel: { fontSize: 10 },
  chart: { height: 145, flexDirection: "row", justifyContent: "space-between", gap: 7 },
  barItem: { flex: 1, height: "100%", alignItems: "center", justifyContent: "flex-end", gap: 6 },
  barTrack: { height: 108, width: "100%", justifyContent: "flex-end", borderRadius: 8, overflow: "hidden" },
  bar: { width: "100%", borderRadius: 8 },
  achievement: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 5 },
  achievementIcon: { width: 35, height: 35, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  logRow: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 7, borderBottomWidth: StyleSheet.hairlineWidth },
  logIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
});
