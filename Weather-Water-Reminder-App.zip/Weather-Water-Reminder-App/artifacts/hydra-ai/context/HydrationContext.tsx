import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { Platform } from "react-native";
import type {
  ReminderSettings,
  SavedLocation,
  UserProfile,
  WaterLog,
} from "@/lib/hydration";

type PersistedState = {
  profile: UserProfile | null;
  location: SavedLocation | null;
  logs: WaterLog[];
  reminders: ReminderSettings;
};

type HydrationContextValue = PersistedState & {
  ready: boolean;
  storageError: string | null;
  finishSetup: (profile: UserProfile, location: SavedLocation | null) => void;
  saveProfile: (profile: UserProfile) => void;
  saveLocation: (location: SavedLocation | null) => void;
  addWater: (amountMl: number) => void;
  setReminderSettings: (settings: ReminderSettings) => Promise<boolean>;
};

const STORAGE_KEY = "hydra-ai-local-v1";
const defaults: PersistedState = {
  profile: null,
  location: null,
  logs: [],
  reminders: { enabled: false, intervalHours: 1, wakeHour: 8, sleepHour: 22 },
};

const HydrationContext = createContext<HydrationContextValue | null>(null);

export function HydrationProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(defaults);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!active || !stored) return;
        try {
          const parsed = JSON.parse(stored) as Partial<PersistedState>;
          setState({
            ...defaults,
            ...parsed,
            reminders: { ...defaults.reminders, ...parsed.reminders },
          });
        } catch {
          setStorageError("Saved data could not be read. You can still use HydraAI on this device.");
        }
      })
      .catch(() => {
        setStorageError("Local storage is unavailable. Your changes may not be saved.");
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {
      setStorageError("Local storage is unavailable. Your latest changes may not be saved.");
    });
  }, [ready, state]);

  const finishSetup = useCallback(
    (profile: UserProfile, location: SavedLocation | null) => {
      setState((current) => ({ ...current, profile, location }));
    },
    [],
  );

  const saveProfile = useCallback((profile: UserProfile) => {
    setState((current) => ({ ...current, profile }));
  }, []);

  const saveLocation = useCallback((location: SavedLocation | null) => {
    setState((current) => ({ ...current, location }));
  }, []);

  const addWater = useCallback((amountMl: number) => {
    if (!Number.isFinite(amountMl) || amountMl < 50 || amountMl > 1500) return;
    const log: WaterLog = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      amountMl: Math.round(amountMl),
      createdAt: new Date().toISOString(),
    };
    setState((current) => ({ ...current, logs: [log, ...current.logs] }));
  }, []);

  const setReminderSettings = useCallback(
    async (settings: ReminderSettings) => {
      if (Platform.OS !== "web") {
        if (settings.enabled) {
          let permission = await Notifications.getPermissionsAsync();
          if (!permission.granted) permission = await Notifications.requestPermissionsAsync();
          if (!permission.granted) return false;
          await Notifications.cancelAllScheduledNotificationsAsync();
          for (
            let hour = settings.wakeHour;
            hour < settings.sleepHour;
            hour += settings.intervalHours
          ) {
            await Notifications.scheduleNotificationAsync({
              content: {
                title: "HydraAI",
                body: "Take a comfortable sip of water when you have a moment.",
                sound: true,
              },
              trigger: {
                type: Notifications.SchedulableTriggerInputTypes.DAILY,
                hour,
                minute: 0,
              },
            });
          }
        } else {
          await Notifications.cancelAllScheduledNotificationsAsync();
        }
      }
      setState((current) => ({ ...current, reminders: settings }));
      return true;
    },
    [],
  );

  const value = useMemo(
    () => ({
      ...state,
      ready,
      storageError,
      finishSetup,
      saveProfile,
      saveLocation,
      addWater,
      setReminderSettings,
    }),
    [
      state,
      ready,
      storageError,
      finishSetup,
      saveProfile,
      saveLocation,
      addWater,
      setReminderSettings,
    ],
  );

  return <HydrationContext.Provider value={value}>{children}</HydrationContext.Provider>;
}

export function useHydration() {
  const context = useContext(HydrationContext);
  if (!context) throw new Error("useHydration must be used inside HydrationProvider");
  return context;
}
