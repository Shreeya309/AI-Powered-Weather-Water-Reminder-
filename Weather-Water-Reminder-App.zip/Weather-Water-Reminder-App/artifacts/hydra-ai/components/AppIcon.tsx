import {
  Activity,
  AlertCircle,
  Award,
  BarChart3,
  Bell,
  Check,
  CheckCircle2,
  CircleHelp,
  Cloud,
  CloudDrizzle,
  Coffee,
  Crosshair,
  Droplet,
  Heart,
  LoaderCircle,
  Lock,
  MapPin,
  Minus,
  Plus,
  RefreshCw,
  Save,
  Search,
  Star,
  Sun,
  User,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react-native";
import type { ColorValue } from "react-native";

const icons: Record<string, LucideIcon> = {
  activity: Activity,
  "alert-circle": AlertCircle,
  award: Award,
  "bar-chart-2": BarChart3,
  bell: Bell,
  check: Check,
  "check-circle": CheckCircle2,
  cloud: Cloud,
  "cloud-drizzle": CloudDrizzle,
  coffee: Coffee,
  crosshair: Crosshair,
  droplet: Droplet,
  heart: Heart,
  loader: LoaderCircle,
  lock: Lock,
  "map-pin": MapPin,
  minus: Minus,
  plus: Plus,
  "refresh-cw": RefreshCw,
  save: Save,
  search: Search,
  star: Star,
  sun: Sun,
  user: User,
  x: X,
  zap: Zap,
};

export function AppIcon({
  name,
  size = 20,
  color,
  strokeWidth = 2,
}: {
  name: string;
  size?: number;
  color?: ColorValue;
  strokeWidth?: number;
}) {
  const Icon = icons[name] ?? CircleHelp;
  return <Icon size={size} color={typeof color === "string" ? color : undefined} strokeWidth={strokeWidth} />;
}
