import React, { type ReactNode } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type ScrollViewProps,
  type TextInputProps,
  type TextStyle,
  type ViewStyle,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

export function Page({
  children,
  refreshControl,
}: {
  children: ReactNode;
  refreshControl?: ScrollViewProps["refreshControl"];
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{
        paddingTop: Platform.OS === "web" ? 67 : insets.top + 12,
        paddingBottom: Platform.OS === "web" ? 122 : insets.bottom + 44,
        paddingHorizontal: 22,
        gap: 18,
      }}
      keyboardShouldPersistTaps="handled"
      refreshControl={refreshControl}
      showsVerticalScrollIndicator={false}
    >
      {children}
    </ScrollView>
  );
}

export function AppText({
  children,
  style,
  muted = false,
}: {
  children: ReactNode;
  style?: StyleProp<TextStyle>;
  muted?: boolean;
}) {
  const colors = useColors();
  return (
    <Text
      style={[
        { color: muted ? colors.mutedForeground : colors.foreground, fontFamily: "Inter_400Regular" },
        style,
      ]}
    >
      {children}
    </Text>
  );
}

export function Card({
  children,
  style,
}: {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderWidth: StyleSheet.hairlineWidth,
          borderRadius: colors.radius + 12,
          padding: 18,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function PageHeading({
  eyebrow,
  title,
  subtitle,
  trailing,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  trailing?: ReactNode;
}) {
  return (
    <View style={styles.headingRow}>
      <View style={{ flex: 1, gap: 4 }}>
        {eyebrow ? (
          <AppText muted style={styles.eyebrow}>
            {eyebrow.toUpperCase()}
          </AppText>
        ) : null}
        <AppText style={styles.heading}>{title}</AppText>
        {subtitle ? <AppText muted style={styles.subtitle}>{subtitle}</AppText> : null}
      </View>
      {trailing}
    </View>
  );
}

export function SectionHeading({
  title,
  trailing,
}: {
  title: string;
  trailing?: ReactNode;
}) {
  return (
    <View style={styles.sectionRow}>
      <AppText style={styles.sectionTitle}>{title}</AppText>
      {trailing}
    </View>
  );
}

export function ActionButton({
  label,
  onPress,
  icon,
  secondary = false,
  disabled = false,
  loading = false,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: ReactNode;
  secondary?: boolean;
  disabled?: boolean;
  loading?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      testID={testID}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: secondary ? colors.secondary : colors.primary,
          opacity: disabled ? 0.48 : pressed ? 0.82 : 1,
        },
      ]}
    >
      {loading ? <ActivityIndicator color={secondary ? colors.primary : colors.primaryForeground} /> : icon}
      <AppText
        style={[
          styles.buttonText,
          { color: secondary ? colors.secondaryForeground : colors.primaryForeground },
        ]}
      >
        {label}
      </AppText>
    </Pressable>
  );
}

export function Pill({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [
        styles.pill,
        {
          backgroundColor: selected ? colors.primary : colors.secondary,
          borderColor: selected ? colors.primary : colors.border,
          opacity: pressed ? 0.8 : 1,
        },
      ]}
    >
      <AppText style={{ color: selected ? colors.primaryForeground : colors.foreground, fontSize: 13, fontFamily: "Inter_600SemiBold" }}>
        {label}
      </AppText>
    </Pressable>
  );
}

export function Field({
  label,
  inputStyle,
  containerStyle,
  ...props
}: TextInputProps & { label: string; inputStyle?: TextStyle; containerStyle?: ViewStyle }) {
  const colors = useColors();
  return (
    <View style={[{ gap: 7 }, containerStyle]}>
      <AppText style={styles.fieldLabel}>{label}</AppText>
      <TextInput
        placeholderTextColor={colors.mutedForeground}
        {...props}
        style={[
          styles.input,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            color: colors.foreground,
          },
          inputStyle,
        ]}
      />
    </View>
  );
}

export function InlineNotice({
  children,
  tone = "info",
}: {
  children: ReactNode;
  tone?: "info" | "error";
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.notice,
        {
          backgroundColor: tone === "error" ? `${colors.destructive}12` : colors.secondary,
          borderColor: tone === "error" ? colors.destructive : colors.border,
        },
      ]}
    >
      <AppText
        style={{ color: tone === "error" ? colors.destructive : colors.secondaryForeground, fontSize: 13, lineHeight: 19 }}
      >
        {children}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  headingRow: { flexDirection: "row", alignItems: "center", gap: 14 },
  eyebrow: { fontSize: 10, letterSpacing: 1.6, fontFamily: "Inter_600SemiBold" },
  heading: { fontSize: 28, lineHeight: 34, fontFamily: "Inter_700Bold", letterSpacing: -0.7 },
  subtitle: { fontSize: 14, lineHeight: 20 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold" },
  button: {
    minHeight: 50,
    borderRadius: 18,
    paddingHorizontal: 18,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
  },
  buttonText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  pill: {
    minHeight: 39,
    borderRadius: 18,
    borderWidth: 1,
    paddingHorizontal: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  fieldLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  input: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 13,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  notice: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
  },
});
