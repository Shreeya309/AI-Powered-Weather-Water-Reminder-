import * as Location from "expo-location";
import { Linking, Platform } from "react-native";
import type { SavedLocation } from "@/lib/hydration";

export async function requestDeviceLocation(): Promise<SavedLocation> {
  if (Platform.OS === "web") {
    if (!navigator.geolocation) throw new Error("Location is unavailable in this browser.");
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) =>
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            label: "Current location",
          }),
        () => reject(new Error("Location access was not granted. You can search for a city instead.")),
        { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 },
      );
    });
  }

  const permission = await Location.requestForegroundPermissionsAsync();
  if (!permission.granted) {
    const error = new Error("Location access was not granted. You can search for a city instead.");
    Object.assign(error, { settingsRequired: !permission.canAskAgain });
    throw error;
  }
  const position = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.Balanced,
  });
  return {
    latitude: position.coords.latitude,
    longitude: position.coords.longitude,
    label: "Current location",
  };
}

export async function openDeviceSettings() {
  if (Platform.OS === "web") return false;
  try {
    await Linking.openSettings();
    return true;
  } catch {
    return false;
  }
}
