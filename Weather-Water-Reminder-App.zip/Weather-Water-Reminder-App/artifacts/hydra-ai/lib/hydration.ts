export type Gender = "woman" | "man" | "nonbinary" | "undisclosed";
export type ActivityLevel = "low" | "moderate" | "high";

export type UserProfile = {
  name: string;
  age: number;
  weightKg: number;
  gender: Gender;
  activityLevel: ActivityLevel;
};

export type SavedLocation = {
  latitude: number;
  longitude: number;
  label: string;
};

export type WeatherForGoal = {
  temperatureC: number;
  humidityPercent: number;
  uvIndex: number | null;
};

export type WaterLog = {
  id: string;
  amountMl: number;
  createdAt: string;
};

export type ReminderSettings = {
  enabled: boolean;
  intervalHours: number;
  wakeHour: number;
  sleepHour: number;
};

export function calculateDailyGoal(
  profile: UserProfile | null,
  weather?: WeatherForGoal | null,
) {
  if (!profile) return 2000;
  const baseMl = profile.weightKg * 30;
  const activityMl = profile.activityLevel === "high" ? 500 : profile.activityLevel === "moderate" ? 250 : 0;
  const heatMl = weather ? Math.max(0, weather.temperatureC - 28) * 40 : 0;
  const humidityMl = weather && weather.humidityPercent >= 70 ? 150 : 0;
  const uvMl = weather && weather.uvIndex !== null && weather.uvIndex >= 6 ? 100 : 0;
  const total = Math.round((baseMl + activityMl + heatMl + humidityMl + uvMl) / 50) * 50;
  return Math.min(4500, Math.max(1200, total));
}

export function localDayKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function isToday(timestamp: string) {
  return localDayKey(new Date(timestamp)) === localDayKey(new Date());
}

export function calculateStreak(logs: WaterLog[], dailyGoalMl: number) {
  let streak = 0;
  const today = new Date();
  for (let offset = 0; offset < 365; offset += 1) {
    const date = new Date(today);
    date.setDate(today.getDate() - offset);
    const dayKey = localDayKey(date);
    const total = logs
      .filter((log) => localDayKey(new Date(log.createdAt)) === dayKey)
      .reduce((sum, log) => sum + log.amountMl, 0);
    if (total >= dailyGoalMl) streak += 1;
    else if (offset === 0) continue;
    else break;
  }
  return streak;
}

export function formatVolume(amountMl: number) {
  if (amountMl >= 1000) {
    const liters = amountMl / 1000;
    return `${Number.isInteger(liters) ? liters.toFixed(0) : liters.toFixed(1)} L`;
  }
  return `${amountMl} ml`;
}

export function getNextReminder(settings: ReminderSettings) {
  const now = new Date();
  for (let hour = settings.wakeHour; hour < settings.sleepHour; hour += settings.intervalHours) {
    if (hour > now.getHours() || (hour === now.getHours() && now.getMinutes() < 1)) {
      return hour;
    }
  }
  return settings.wakeHour;
}

export function formatHour(hour: number) {
  const suffix = hour >= 12 ? "PM" : "AM";
  const display = hour % 12 || 12;
  return `${display}:00 ${suffix}`;
}
