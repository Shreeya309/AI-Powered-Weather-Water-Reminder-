import { Router, type IRouter } from "express";
import healthRouter from "./health";
import weatherRouter from "./weather";
import hydrationRouter from "./hydration";

const router: IRouter = Router();

router.use(healthRouter);
router.use(weatherRouter);
router.use(hydrationRouter);

export default router;
