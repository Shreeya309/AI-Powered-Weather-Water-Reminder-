import OpenAI from "openai";
import { Router } from "express";

const router = Router();
const requestCounts = new Map<string, { count: number; resetsAt: number }>();

type InsightInput = {
  age: number;
  weightKg: number;
  gender: "woman" | "man" | "nonbinary" | "undisclosed";
  activityLevel: "low" | "moderate" | "high";
  temperatureC: number;
  humidityPercent: number;
  uvIndex: number | null;
  goalMl: number;
  consumedMl: number;
};

function isInsightInput(value: unknown): value is InsightInput {
  if (!value || typeof value !== "object") return false;
  const input = value as Record<string, unknown>;
  return (
    Number.isInteger(input.age) &&
    Number(input.age) >= 18 &&
    Number(input.age) <= 110 &&
    typeof input.weightKg === "number" &&
    input.weightKg >= 30 &&
    input.weightKg <= 300 &&
    ["woman", "man", "nonbinary", "undisclosed"].includes(String(input.gender)) &&
    ["low", "moderate", "high"].includes(String(input.activityLevel)) &&
    typeof input.temperatureC === "number" &&
    input.temperatureC >= -60 &&
    input.temperatureC <= 65 &&
    Number.isInteger(input.humidityPercent) &&
    Number(input.humidityPercent) >= 0 &&
    Number(input.humidityPercent) <= 100 &&
    (input.uvIndex === null ||
      (typeof input.uvIndex === "number" && input.uvIndex >= 0 && input.uvIndex <= 30)) &&
    Number.isInteger(input.goalMl) &&
    Number(input.goalMl) >= 500 &&
    Number(input.goalMl) <= 6000 &&
    Number.isInteger(input.consumedMl) &&
    Number(input.consumedMl) >= 0 &&
    Number(input.consumedMl) <= 12000
  );
}

function allowRequest(ip: string) {
  const now = Date.now();
  const entry = requestCounts.get(ip);
  if (!entry || entry.resetsAt <= now) {
    requestCounts.set(ip, { count: 1, resetsAt: now + 60 * 60 * 1000 });
    return true;
  }
  if (entry.count >= 12) return false;
  entry.count += 1;
  return true;
}

router.post("/hydration/insight", async (req, res) => {
  if (!isInsightInput(req.body)) {
    return res.status(400).json({ error: "Hydration context is incomplete or invalid." });
  }
  if (!allowRequest(req.ip ?? "unknown")) {
    return res.status(429).json({ error: "Please wait before requesting another insight." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: "AI guidance is not configured." });
  }

  try {
    const client = new OpenAI({ apiKey });
    const response = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      messages: [
        {
          role: "system",
          content:
            "Give one practical, calm hydration coaching tip in 1-2 sentences. This is general wellness guidance, not medical advice. Do not diagnose, prescribe, change the numerical water target, recommend chugging, or make claims about preventing illness. Encourage small, steady sips. If the user is already at or above their target, acknowledge that without encouraging excess intake.",
        },
        {
          role: "user",
          content: JSON.stringify({
            age: req.body.age,
            weightKg: req.body.weightKg,
            gender: req.body.gender,
            activityLevel: req.body.activityLevel,
            weather: {
              temperatureC: req.body.temperatureC,
              humidityPercent: req.body.humidityPercent,
              uvIndex: req.body.uvIndex,
            },
            dailyGoalMl: req.body.goalMl,
            consumedSoFarMl: req.body.consumedMl,
          }),
        },
      ],
    });
    const message = response.choices[0]?.message.content?.trim();
    if (!message) {
      return res.status(502).json({ error: "AI guidance returned no message." });
    }
    return res.json({ message, generatedAt: new Date().toISOString() });
  } catch {
    return res.status(502).json({ error: "AI guidance is temporarily unavailable." });
  }
});

export default router;
