import { Router } from "express";

const router = Router();

type OpenWeatherCurrent = {
  name?: string;
  main?: { temp?: number; feels_like?: number; humidity?: number };
  weather?: Array<{ description?: string; icon?: string }>;
  sys?: { country?: string };
};

type OpenWeatherUv = {
  current?: { uvi?: number };
};

type OpenWeatherPlace = {
  name?: string;
  country?: string;
  state?: string;
  lat?: number;
  lon?: number;
};

function getApiKey() {
  return process.env.OPENWEATHERMAP_API_KEY;
}

router.get("/weather/current", async (req, res) => {
  const lat = Number(req.query.lat);
  const lon = Number(req.query.lon);

  if (
    !Number.isFinite(lat) ||
    !Number.isFinite(lon) ||
    lat < -90 ||
    lat > 90 ||
    lon < -180 ||
    lon > 180
  ) {
    return res.status(400).json({ error: "Valid latitude and longitude are required." });
  }

  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({ error: "Weather service is not configured." });
  }

  try {
    const query = new URLSearchParams({
      lat: String(lat),
      lon: String(lon),
      units: "metric",
      appid: apiKey,
    });
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?${query}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!response.ok) {
      return res.status(502).json({ error: "Unable to retrieve current weather." });
    }
    const current = (await response.json()) as OpenWeatherCurrent;

    let uvIndex: number | null = null;
    const uvQuery = new URLSearchParams({
      lat: String(lat),
      lon: String(lon),
      exclude: "minutely,hourly,daily,alerts",
      appid: apiKey,
    });
    try {
      const uvResponse = await fetch(
        `https://api.openweathermap.org/data/3.0/onecall?${uvQuery}`,
        { signal: AbortSignal.timeout(7000) },
      );
      if (uvResponse.ok) {
        const uv = (await uvResponse.json()) as OpenWeatherUv;
        if (Number.isFinite(uv.current?.uvi)) uvIndex = uv.current!.uvi!;
      }
    } catch {
      // Some OpenWeatherMap plans do not include UV data; temperature and humidity still work.
    }

    const main = current.main;
    if (
      !main ||
      !current.name ||
      !Number.isFinite(main?.temp) ||
      !Number.isFinite(main?.feels_like) ||
      !Number.isFinite(main?.humidity)
    ) {
      return res.status(502).json({ error: "Weather provider returned incomplete data." });
    }

    return res.json({
      location: current.name,
      country: current.sys?.country ?? "",
      temperatureC: main.temp,
      feelsLikeC: main.feels_like,
      humidityPercent: main.humidity,
      condition: current.weather?.[0]?.description ?? "Current conditions",
      iconCode: current.weather?.[0]?.icon ?? "",
      uvIndex,
      fetchedAt: new Date().toISOString(),
    });
  } catch {
    return res.status(502).json({ error: "Weather provider is temporarily unavailable." });
  }
});

router.get("/weather/geocode", async (req, res) => {
  const city = typeof req.query.city === "string" ? req.query.city.trim() : "";
  if (city.length < 2 || city.length > 100) {
    return res.status(400).json({ error: "Enter a city name with 2 to 100 characters." });
  }

  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({ error: "Weather service is not configured." });
  }

  try {
    const query = new URLSearchParams({ q: city, limit: "5", appid: apiKey });
    const response = await fetch(
      `https://api.openweathermap.org/geo/1.0/direct?${query}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!response.ok) {
      return res.status(502).json({ error: "Unable to search for that location." });
    }
    const places = (await response.json()) as OpenWeatherPlace[];
    return res.json(
      places
        .filter(
          (place) =>
            typeof place.name === "string" &&
            Number.isFinite(place.lat) &&
            Number.isFinite(place.lon),
        )
        .map((place) => ({
          name: place.name,
          country: place.country ?? "",
          ...(place.state ? { state: place.state } : {}),
          latitude: place.lat,
          longitude: place.lon,
        })),
    );
  } catch {
    return res.status(502).json({ error: "Location search is temporarily unavailable." });
  }
});

export default router;
