---
name: Expo web icon rendering
description: Reliable icon rendering across HydraAI's native app and web preview.
---

For Expo screens shared with web preview and native, prefer SVG-based icons such as lucide-react-native over icon-font glyphs when a preview shows missing-glyph boxes. Loading the vector icon font through the app font hook did not fix the web rendering here; SVG icons rendered correctly.

**Why:** the web preview's icon-font rendering differed from the native experience, making primary controls look broken even though the app ran.

**How to apply:** verify icons in the actual Expo web preview, not just by type-checking or checking the native code path.
