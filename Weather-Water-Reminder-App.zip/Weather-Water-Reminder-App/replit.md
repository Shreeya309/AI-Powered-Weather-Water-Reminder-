# HydraAI

A cross-platform hydration companion that adjusts daily water estimates and reminders to a user's profile, activity, and local weather.

## Run & Operate

- `pnpm --filter @workspace/hydra-ai run dev` — run the Expo app
- `pnpm --filter @workspace/api-server run dev` — run the Express API server
- `pnpm --filter @workspace/hydra-ai run typecheck` — check the mobile app
- `pnpm --filter @workspace/api-server run typecheck` — check the API server
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API client and validation schemas
- Required Replit Secrets: `OPENAI_API_KEY`, `OPENWEATHERMAP_API_KEY`

The root `pnpm run typecheck` also checks the reusable mockup sandbox. Its existing React ref typing errors in the calendar and spinner components are unrelated to HydraAI; the app and API server have separate passing type checks.

## Stack

- pnpm workspaces, Node.js 24, TypeScript
- Mobile app: Expo, React Native, Expo Router
- API: Express 5
- External services: OpenWeatherMap and OpenAI
- On-device persistence: AsyncStorage

## Where things live

- `artifacts/hydra-ai/app/` — onboarding and mobile screens
- `artifacts/hydra-ai/context/HydrationContext.tsx` — local profile, drink log, and reminder state
- `artifacts/hydra-ai/lib/hydration.ts` — goal estimate and progress calculations
- `artifacts/api-server/src/routes/weather.ts` — OpenWeatherMap current-weather and city-search routes
- `artifacts/api-server/src/routes/hydration.ts` — on-demand AI hydration insight route
- `lib/api-spec/openapi.yaml` — source of truth for shared API contracts

## Architecture decisions

- The daily numeric target is a transparent weight/activity/weather estimate; the language model adds a short coaching tip but cannot change the target.
- Profile, location selection, reminder preferences, and drink history stay on-device. API requests only run for weather and explicitly requested AI tips.
- API credentials remain server-side. AI insight requests validate their context and are rate-limited.
- Reminders use local device notifications and remain off until the user enables them and grants permission.

## Product

- Adult onboarding for name, age, weight, gender, activity level, and optional weather location
- Weather-aware daily hydration estimate with OpenWeatherMap temperature, humidity, and optional UV index
- Quick water logging, a seven-day trend, daily goal streaks, and achievement badges
- Opt-in local reminders with configurable interval and quiet hours
- User-requested AI tips generated from current weather and hydration progress
- Wellness estimates only; the app does not diagnose or replace clinician guidance

## User preferences

- Use the attached presentation as the product requirements source.

## Gotchas

- Never expose `OPENAI_API_KEY` or `OPENWEATHERMAP_API_KEY` to the mobile client or include secret values in logs.
- OpenWeatherMap UV data may not be enabled on every account; temperature and humidity remain available when the UV endpoint is unavailable.
- Expo local notifications are native-device behavior; the web preview can show the schedule but cannot deliver those alerts.

## Pointers

- See the `expo` skill for mobile workflow and device-permission conventions.
- See the `pnpm-workspace` skill for API contracts and workspace package rules.
